﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class CursoModel
    {
        public string Nome { get; set; }
        public string Modalidade { get; set; }
        public int Vagas { get; set; }

        public static List<CursoModel> CriarLista()
        {
            var lista = new List<CursoModel>();

            lista.Add(new CursoModel() { Nome = "Desenvolvimento de Sistemas", Modalidade = "Presencial", Vagas = 40});
            lista.Add(new CursoModel() { Nome = "Comércio", Modalidade = "EaD ", Vagas = 40});
            lista.Add(new CursoModel() { Nome = "Design de Interiores", Modalidade = "Presencial", Vagas = 40});
            lista.Add(new CursoModel() { Nome = "Finanças", Modalidade = "Presencial", Vagas = 40});
            lista.Add(new CursoModel() { Nome = "GESTÃO E NEGÓCIOS", Modalidade = "EAD", Vagas = 40});

            return lista;
        }
    }
}
