﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class AlunoModel2
    {
        public string Nome { get; set; }
        public string Curso { get; set; }
        public DateTime Matricula { get; set; }
        public int Faltas { get; set; }

        public AlunoModel2()
        {
            Nome = "Nadja";
            Curso = "Desenvolvimento de Sistemas";
            Faltas = 12;
            Matricula = new DateTime(2023,2,12);
        }

        public static AlunoModel2 CriarAluno()
        {
            var aluno = new AlunoModel2();
            aluno.Nome = "Elias";
            return aluno;
        }
        public static List<AlunoModel2> CriarLista()
        {
            var lista = new List<AlunoModel2>();
           // lista.Add(new AlunoModel2());
           // lista.Add(AlunoModel2.CriarAluno());
           lista.Add(new AlunoModel2() { Nome= "Elias", Curso = "DS", Faltas = 10, Matricula = DateTime.Now});
           lista.Add(new AlunoModel2() { Nome= "Marden", Curso = "DS", Faltas = 2, Matricula = DateTime.Now});
           lista.Add(new AlunoModel2() { Nome= "Radjalisson", Curso = "DS", Faltas = 15, Matricula = DateTime.Now});
           lista.Add(new AlunoModel2() { Nome= "Mérilu", Curso = "DS", Faltas = 7, Matricula = DateTime.Now});

            return lista;
        }
    }
}